function showPostFrom() {
    document.getElementById("center-form-post-div").style.display = "block";
}